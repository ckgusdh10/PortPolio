from pico2d import *

class Score:
    score = 0.0

    def stage1_socre(self):
        self.score += 5

    def stage2_score(self):
        self.score += 10